package com.maxsalvadorportfolio.jmv2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jmv2Application {

	public static void main(String[] args) {
		SpringApplication.run(Jmv2Application.class, args);
	}

}
